# jawsdays-ask-handson-advanced

JAWS DAYS 2017で開催されたAlexa Skills Kitの応用編ハンズオンです。  
http://jawsdays2017.jaws-ug.jp/

ハンズオンの手順については、[wiki](https://github.com/sparkgene/jawsdays-ask-handson-advanced/wiki)に書かれていますので、そちらを参考に進めてください。
